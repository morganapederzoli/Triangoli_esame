# Classe Triangoli
Implementazione di una classe in C++ usata per studiare i triangoli. 
I metodi della classe permettoni di trovare area, perimetro, baricentro, circocentro ed incentro di ogni triangolo di cui siano noti o 3 lati o 2  lati ed un angolo o 1 lato e i 2 angoli adiacenti ad essi.
La classe prevede infine un'implementazione grafica tramite gnuplot.
